[{
    "_id": {
      "$oid": "63ff16524765db333fa0e863"
    },
    "name": {
      "fName": "Ananthi",
      "mName": "Satheesh",
      "lName": "S"
    },
    "cropid": 100001,
    "croppoints": 7050,
    "password": "$2b$10$zTR/Qz1gAeEu2hgYD8Yoh.4VNVf/DPFHVkHCeD1uCr6zdPAsPkc0q",
    "mobileNumber": "",
    "email": "ananthisiva9@gmail.com",
    "UserTitle": "Mrs",
    "UserTier": "Diamond",
    "terms": true,
    "notification": true,
    "promocode": "5h8B7fiv4",
    "refercode": "awYyUFsSS",
    "loyaltyList": 1,
    "interestList": [],
    "mktNotification": true,
    "smsNotification": false,
    "emailNotification": true,
    "address": [
      {
        "address": {
          "line1": "1A",
          "line2": "WestStreet",
          "line3": "Chennai",
          "state": "Tamilnadu",
          "pin": "1234"
        },
        "_id": {
          "$oid": "6406ffe9c33210737d31f370"
        }
      }
    ],
    "__v": 0,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFuYW50aGlzaXZhOUBnbWFpbC5jb20iLCJpYXQiOjE2Nzk0NzU5NTV9.QghBV0EHnNDid2ssuLyLj7nQft6srXa__Iyk4Wezl78",
    "biometricterms": false,
    "gender": "Female",
    "dob": {
      "$date": {
        "$numberLong": "886982400000"
      }
    },
    "agegroup": "From 18 to 35",
    "avatar": "C:\\Users\\Dell\\Desktop\\themeforest-5fJe2Dq8-harri-electronics-ecommerce-react-next-js-template\\harri-shop-server/uploads/47945f0e-f2bd-4728-9b57-5d1adadca6787262927560521770880.jpg",
    "feedback": "4",
    "login_method": 2
  },{
    "_id": {
      "$oid": "63ff249df959b0e40b747f6f"
    },
    "name": {
      "fName": "Siva",
      "mName": "R",
      "lName": "Rishi"
    },
    "cropid": 100002,
    "croppoints": 15750,
    "password": "$2b$10$iHCU5migR39ePCUYjc89gOUvAW37upQ2ui4hAouVkdfsxKitJGIee",
    "mobileNumber": "",
    "email": "vigneshraaj19@gmail.com",
    "UserTitle": "Mr",
    "UserTier": "Diamond",
    "gender": "Male",
    "terms": true,
    "biometricterms": true,
    "notification": false,
    "promocode": "",
    "refercode": "zR4hjAGPD",
    "loyaltyList": 1,
    "interestList": null,
    "dob": {
      "$date": {
        "$numberLong": "613267200000"
      }
    },
    "agegroup": "From 18 to 35",
    "avatar": "C:\\Users\\Dell\\Desktop\\themeforest-5fJe2Dq8-harri-electronics-ecommerce-react-next-js-template\\harri-shop-server/uploads/6a276273-58d6-41b0-8f4c-fe8e11f144af4078676383660245994.jpg",
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": "4",
    "address": [
      {
        "address": {
          "line1": "Guduvanchery",
          "line2": "Chengalpattu",
          "line3": "Kancheepuram",
          "state": "Tamilnadu",
          "pin": "6032"
        },
        "_id": {
          "$oid": "63ff3a77f3c6733c09d508ef"
        }
      }
    ],
    "__v": 0,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InZpZ25lc2hyYWFqMTlAZ21haWwuY29tIiwiaWF0IjoxNjc5NDgxOTI0fQ.AM0t7XZ72mcpYruJNZRFQLaNvdNpnwSYujWRo4Tb630",
    "login_method": 2
  },{
    "_id": {
      "$oid": "63ff42aab346c46afb7b9028"
    },
    "name": {
      "fName": "Shiv",
      "mName": "R",
      "lName": "R"
    },
    "cropid": 100003,
    "croppoints": 0,
    "password": "$2b$10$AOdjKzImlQ.r510JGqYxJuk7VcywDMY65UsERftmf/EHwc/BsumKC",
    "mobileNumber": "",
    "email": "rsiva.rishi@gmail.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": true,
    "promocode": "awYyUFsSS",
    "refercode": "612Ic_nRx",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InJzaXZhLnJpc2hpQGdtYWlsLmNvbSIsImlhdCI6MTY3Nzc1MTM0Nn0.DTcvm7Ha0OSqMnqx8fVLDaQcPHIfAszK9Q1fFcgvmBE"
  },{
    "_id": {
      "$oid": "640042c2dff3187050fed40a"
    },
    "name": {
      "fName": "Kani",
      "mName": "P",
      "lName": "Pugazh"
    },
    "cropid": 100004,
    "croppoints": 30,
    "password": "$2b$10$CC.u/cQBpR7Ro6RVdt1QzOgLAxEghXHEY49hjv7WsnWULhpDV9vWu",
    "mobileNumber": "",
    "email": "kanipugazh1997@gmail.com",
    "UserTitle": "Miss",
    "UserTier": "Gold",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": true,
    "promocode": "awYyUFsSS",
    "refercode": "xfumXhYYu",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImthbmlwdWdhemgxOTk3QGdtYWlsLmNvbSIsImlhdCI6MTY3NzczOTQ3Nn0.f4lUHQboLtU7oKf5X17GADdZCpbAelw1UjsE7fdqHug"
  },{
    "_id": {
      "$oid": "640045c1340ee5acf3b1e527"
    },
    "name": {
      "fName": "Pradeep",
      "mName": "K",
      "lName": "Kumar"
    },
    "cropid": 100005,
    "croppoints": 0,
    "password": "$2b$10$BxOxbmKoxIEdi17zzLXgbOzIBU.J5fDlYtDDmFkSI2H2Hfp6fAbAm",
    "mobileNumber": "",
    "email": "pradeepkumar@pearlcons.com",
    "UserTitle": "Mr",
    "UserTier": "Gold",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "xfumXhYYu",
    "refercode": "Mh0jgLSEa",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": "4",
    "address": [],
    "__v": 0,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InByYWRlZXBrdW1hckBwZWFybGNvbnMuY29tIiwiaWF0IjoxNjc3NzM5NTU1fQ.uVMnt_vxenGf0RCiLBk9zzf6uMmjM3eQkDykC7h80JE"
  },{
    "_id": {
      "$oid": "640ab373cc34cec6481c94a1"
    },
    "name": {
      "fName": "Test",
      "mName": "T",
      "lName": "User"
    },
    "cropid": 100006,
    "croppoints": 0,
    "password": "$2b$10$1Baf0vfDnOcy2FU.dWqa8ODUiya2qALDqnApR8v8y0GquTXXuCwJm",
    "mobileNumber": "",
    "email": "dolahe4130@proexbol.com",
    "UserTitle": "Mrs",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": true,
    "promocode": "",
    "refercode": "IpKAeOpNW",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "640ab76f7e93f182fe8888e4"
    },
    "name": {
      "fName": "Test",
      "mName": "U",
      "lName": "Userr"
    },
    "cropid": 100007,
    "croppoints": 0,
    "password": "$2b$10$BvQ4VFuLY5Z1s/zHTbULouckLL1Mr4MzMeuMzFBk3luRYbgPnoAJO",
    "mobileNumber": "",
    "email": "higom68512@rolenot.com",
    "UserTitle": "Mrs",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": true,
    "promocode": "",
    "refercode": "gtfLpd7EM",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "640ac8750ceb8304d6527895"
    },
    "name": {
      "fName": "Test",
      "mName": "T",
      "lName": "Userrr"
    },
    "cropid": 100008,
    "croppoints": 0,
    "password": "$2b$10$6603cXDg4ghrsz5lqFErt.CVcCwhdYxqbfnKM0ViISVYt/MFPYalu",
    "mobileNumber": "",
    "email": "damofas733@rolenot.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": true,
    "promocode": "",
    "refercode": "s8uo0sSAw",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "640c4454c78747fd9cc12a6f"
    },
    "name": {
      "fName": "Testing",
      "mName": "T",
      "lName": "User"
    },
    "cropid": 100009,
    "croppoints": 0,
    "password": "$2b$10$qbPNgYuewrOA97sbJednQO6NIQpDIlINf.V2idnop53.mLeE0KAoG",
    "mobileNumber": "",
    "email": "garac78378@orgria.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": true,
    "promocode": "",
    "refercode": "Oi201ZztU",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImdhcmFjNzgzNzhAb3JncmlhLmNvbSIsImlhdCI6MTY3ODUyNTk5NH0.A3HezHyGKzrz9iAS-uUIen0AwblHhegRqdFWqd-n0yg"
  },{
    "_id": {
      "$oid": "640c4b26a6c5befbed4b579a"
    },
    "name": {
      "fName": "Testingg",
      "mName": "N",
      "lName": "New"
    },
    "cropid": 100010,
    "croppoints": 0,
    "password": "$2b$10$Pg0jz5OvVY8nFyMYbgIokenIhusKGYJObPy9nhiz0VYgHxQz4Sjcm",
    "mobileNumber": "",
    "email": "vibigan283@terkoer.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "",
    "refercode": "7fSeZz70U",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "640c4da0c30e8e3253e81d65"
    },
    "name": {
      "fName": "Testinggg",
      "mName": "n",
      "lName": "n"
    },
    "cropid": 100011,
    "croppoints": 0,
    "password": "$2b$10$W5cLx64B8flFay6an6z0xuEazZP.yIwJ0dBeEGvDTvbob2GoSndWS",
    "mobileNumber": "",
    "email": "cononeg844@proexbol.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "",
    "refercode": "ZIhUKeGZq",
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImNvbm9uZWc4NDRAcHJvZXhib2wuY29tIiwiaWF0IjoxNjc4NTI3OTI0fQ.-lhnVBlnSid9zkYLGTCG47TAMxndDyQOHYk90LWWHn4"
  },{
    "_id": {
      "$oid": "6411a28c9e6c1e2d7fec8cbb"
    },
    "name": {
      "fName": "User",
      "mName": "U",
      "lName": "U"
    },
    "cropid": 100012,
    "croppoints": 0,
    "password": "$2b$10$kSX32I4sCScGVTgmAtm5O.MRViV5epsV7pifqJ.MU49aVtxUTigJy",
    "mobileNumber": "",
    "email": "ananthi.s@pearlcons.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "kZPttAbD5",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "6411a62c9e6c1e2d7fec8cd1"
    },
    "name": {
      "fName": "abcd",
      "mName": "abcd",
      "lName": "abcd"
    },
    "cropid": 100013,
    "croppoints": 0,
    "password": "$2b$10$APTtnvYbqiDJ1xrCR4EHwu.qv8vo.3Z4p3As6AqnDRssxiSFD9WSO",
    "mobileNumber": "",
    "email": "segiv18358@huvacliq.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "N_aHGh34s",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "6411a6d59e6c1e2d7fec8cdf"
    },
    "name": {
      "fName": "efgh",
      "mName": "efgc",
      "lName": "e"
    },
    "cropid": 100014,
    "croppoints": 0,
    "password": "$2b$10$6Cmh0UUTvcfIwKPnslkfm.CfXXR71019EasWFALS3NE7EMuXoJyVW",
    "mobileNumber": "",
    "email": "lolej45574@asoflex.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "LZGPcKBrp",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "6411a7569e6c1e2d7fec8cf7"
    },
    "name": {
      "fName": "asdasdf",
      "mName": "dvcsdvsf",
      "lName": "asdvcsdzv"
    },
    "cropid": 100015,
    "croppoints": 0,
    "password": "$2b$10$rOO0gsbPoy2xGqy0dA.pc.AvEUajwuAYP1MRexn7lkRCfF5xehaI2",
    "mobileNumber": "",
    "email": "kesota4393@etondy.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "2dcSRmFjj",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "6411a9469e6c1e2d7fec8d11"
    },
    "name": {
      "fName": "AsdRSG",
      "mName": "ASDGBF",
      "lName": "SADFVASDHGS"
    },
    "cropid": 100016,
    "croppoints": 0,
    "password": "$2b$10$lwUuf1vouTG4slEm2Q8HB.ZrIa7aa525mR0bfmVVIk5oLs5bCc0Ki",
    "mobileNumber": "",
    "email": "kekoso3174@asoflex.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "EzzA9F5Ny",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "6411aa3e9e6c1e2d7fec8d1f"
    },
    "name": {
      "fName": "ASDGF",
      "mName": "adfg",
      "lName": "adfgbsb"
    },
    "cropid": 100017,
    "croppoints": 0,
    "password": "$2b$10$9cCt8dtUoFbrDoMGU7PfweqBd7RuHIx3MxTgriyoZaqcP5CYJpCAW",
    "mobileNumber": "",
    "email": "cosoci4692@huvacliq.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "J8BDzwSJy",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "6411ab009e6c1e2d7fec8d31"
    },
    "name": {
      "fName": "axdgcv",
      "mName": "xfbdxb",
      "lName": "zbxgfcbz"
    },
    "cropid": 100018,
    "croppoints": 0,
    "password": "$2b$10$15dlCPxgJ7lhUnpdDPYiiupt8FCe1SgeTHQHV9TWyzcVw6a0CCmq.",
    "mobileNumber": "",
    "email": "piwedig570@etondy.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "dj5w2X7KQ",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "6411ab6b9e6c1e2d7fec8d4d"
    },
    "name": {
      "fName": "sdvfdfv",
      "mName": "agsfdgv",
      "lName": "afvcbf"
    },
    "cropid": 100019,
    "croppoints": 0,
    "password": "$2b$10$gShhT6Ra0LP7kgOVjjwCPO2u1VB5yHLY5iATWm2NzPVN4XPT7.KKu",
    "mobileNumber": "",
    "email": "dakavi3482@etondy.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "VU8x4B4UN",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "6411abc89e6c1e2d7fec8d5b"
    },
    "name": {
      "fName": "aszCVzfd",
      "mName": "DCVfdzvbfgx",
      "lName": "cvbxgnbg"
    },
    "cropid": 100020,
    "croppoints": 0,
    "password": "$2b$10$C2tnk.62kzp4NKpccxt9YOefT/GWqClJ/kVyfPW4Go.jzA6b0GXlO",
    "mobileNumber": "",
    "email": "rorala6768@etondy.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "awYyUFsSS",
    "refercode": "yNsS1xvmc",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "64198712c9a94132f0dd6544"
    },
    "name": {
      "fName": "Ananthi",
      "mName": "S",
      "lName": "S"
    },
    "cropid": 100021,
    "croppoints": 0,
    "password": "$2b$10$29zwWlAP4KwHSKOnZDed0e9ZU4HD4mj9XKCr/hvE3U5DEZ/RTk4qu",
    "mobileNumber": "",
    "email": "ananthisiva09@outlook.com",
    "UserTitle": "Mrs",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "",
    "refercode": "wEkJNDp8_",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0,
    "token": "null"
  },{
    "_id": {
      "$oid": "6419f1acbbdd224a107e6ea3"
    },
    "name": {
      "fName": "wetwet",
      "mName": "wetwet",
      "lName": "wtwtw"
    },
    "cropid": 100022,
    "croppoints": 0,
    "password": "$2b$10$7pWdfPz9CxCX4xkBabJvjuftKk74/lMS1DRR6sL.ObZJhEfr3Pzla",
    "mobileNumber": "9274827383",
    "email": "vigneshraaj21@gmail.com",
    "UserTitle": "mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": true,
    "promocode": "pup1aFLna",
    "refercode": "LrLssSSbQ",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  },{
    "_id": {
      "$oid": "641abf4aebe094f86423f4e8"
    },
    "name": {
      "fName": "sdafda",
      "mName": "asdgfad",
      "lName": "agfadfg"
    },
    "cropid": 100023,
    "croppoints": 0,
    "password": "$2b$10$3A/hxxUcIUqTFzs7AUs/JeW2FqFjDifHz.9e3kyWARvztuaScURVW",
    "mobileNumber": "",
    "email": "laxmipriya.ks@pearlcons.com",
    "UserTitle": "Mr",
    "UserTier": "Base",
    "gender": null,
    "terms": true,
    "biometricterms": false,
    "notification": false,
    "promocode": "",
    "refercode": "En1OpNQCl",
    "login_method": 2,
    "loyaltyList": null,
    "interestList": null,
    "dob": null,
    "agegroup": null,
    "avatar": null,
    "mktNotification": true,
    "smsNotification": true,
    "emailNotification": true,
    "feedback": null,
    "address": [],
    "__v": 0
  }]