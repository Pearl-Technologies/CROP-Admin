export default {
  spacing: factor => `${0.25 * factor}rem`
}
