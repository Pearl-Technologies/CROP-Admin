const product=[
    {
        id:"808080707008080808",
        title:"cup",
        bidPrice:50,
        points:28,
        shortDescription: "cup cup cup",
        description:"cup",
        apply:"both",
        status:"notActive",
        availDate:{
            from:"25/03/2023",
            to:"30/03/2023"
        },
        image:"https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcSc3PFjryM2Y1PzI2wtFjD1v4yFCarcrE-YQrpE6J5UqSFMCPlwaq_9bkBTuDQNojayFMhlaZUSxIa1f-49hKrvekcqlmb0M4SyPmUKYos&usqp=CAE",
        sustomiseMsg:"thank you",
        rating:"5",
        likes:"10",
        sector:"hotel",
        createdAt:"25/03/2023",
        updatedAt:"25/03/2023"
    },
    {
        id:"808080707008080808",
        title:"cup",
        bidPrice:50,
        points:28,
        shortDescription: "cup cup cup",
        description:"cup",
        apply:"both",
        status:"notActive",
        availDate:{
            from:"25/03/2023",
            to:"30/03/2023"
        },
        image:"https://meltingpot-food.in/wp-content/uploads/2021/05/PaniPuriConcentrate_front.jpg",
        sustomiseMsg:"thank you",
        rating:"5",
        likes:"10",
        sector:"hotel",
        createdAt:"25/03/2023",
        updatedAt:"25/03/2023"
    },
    {
        id:"808080707008080808",
        title:"cup",
        bidPrice:50,
        points:28,
        shortDescription: "cup cup cup",
        description:"cup",
        apply:"both",
        status:"notActive",
        availDate:{
            from:"25/03/2023",
            to:"30/03/2023"
        },
        image:"https://static.toiimg.com/photo/70975425.cms",
        sustomiseMsg:"thank you",
        rating:"5",
        likes:"10",
        sector:"hotel",
        createdAt:"25/03/2023",
        updatedAt:"25/03/2023"
    }
]